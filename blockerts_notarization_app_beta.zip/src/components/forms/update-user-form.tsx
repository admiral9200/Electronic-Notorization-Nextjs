"use client"

export function UpdateUserForm(): JSX.Element {
  return <div>TODO: Update User Form</div>
}
