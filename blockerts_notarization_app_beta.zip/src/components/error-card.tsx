export function ErrorCard(): JSX.Element {
  return <div>Error card. Under construction.</div>
}
