// import { siteConfig } from "@/config/site"

// import NextAuth from "next-auth"
// import GoogleProvider from "next-auth/providers/google"

export { GET, POST } from "@/auth"

// export const runtime = "edge"
// export const preferredRegion = siteConfig.hostingRegion