export default function TermsOfServicePage(): JSX.Element {
  return <div>Terms of Service Page</div>
}
