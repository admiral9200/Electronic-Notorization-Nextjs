export default function BlogPostNotFoundPage(): JSX.Element {
  return <div>Blog post not found page. Under construction.</div>
}
