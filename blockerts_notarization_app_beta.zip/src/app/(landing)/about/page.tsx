export default function AboutPage(): JSX.Element {
  return (
    <div className="flex min-h-screen w-full items-center justify-center">
      About Page
    </div>
  )
}
