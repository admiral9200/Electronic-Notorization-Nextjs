export default function PrivacyPolicyPage(): JSX.Element {
  return <div>Privacy Policy Page</div>
}
