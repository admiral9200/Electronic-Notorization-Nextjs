export default function DashboardPage(): JSX.Element {
  return (
    <div>
      Dashboard page. This page is protected. You should only see it when you
      are authenticated.
    </div>
  )
}
