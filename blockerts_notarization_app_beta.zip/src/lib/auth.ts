import { cache } from "react"
import { auth } from "@/auth"

export default cache(auth)
