export const DEFAULT_SIGNIN_REDIRECT = "/"
export const DEFAULT_SIGNOUT_REDIRECT = "/"
export const DEFAULT_UNAUTHENTICATED_REDIRECT = "/signin"
export const DEFAULT_AUTHENTICATED_REDIRECT = "/type"
